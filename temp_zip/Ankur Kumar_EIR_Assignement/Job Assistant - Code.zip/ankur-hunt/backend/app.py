"""
ankur.hunt — Flask Backend
Rule-based scoring, template emails, multi-source job search
Free APIs: Remotive, RemoteOK, Arbeitnow (no key), SerpAPI (optional), Gmail, Sheets, Notion, Slack
"""

import os
import json
import base64
import datetime
import re
import hashlib
import random
from pathlib import Path

import requests as http_requests
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).resolve().parent.parent / ".env")

app = Flask(__name__)
CORS(app)

# ═══════════════════════════════════════════════
# ANKUR'S PROFILE
# ═══════════════════════════════════════════════

PROFILE = {
    "name": "Ankur",
    "current_role": "Associate Product Manager & Chief of Staff at DevKraft Technologies",
    "experience_years": "1-3",
    "education": "MA Economics & International Trade (IIFT Delhi), BA Economics Hons (Motilal Nehru College, Delhi University)",
    "target_roles": [
        "Chief of Staff", "Founder's Office", "Entrepreneur in Residence", "EIR",
        "Associate Product Manager", "Product Manager", "Strategy & Operations",
        "Growth Manager", "VC Analyst", "VC Associate", "Investment Analyst",
        "Management Consultant", "Business Analyst", "Program Manager"
    ],
    "preferred_industries": [
        "AI/ML", "SaaS", "B2B Enterprise", "DeepTech", "Venture Capital",
        "FinTech", "EdTech", "Enterprise Software", "Management Consulting",
        "Social Sector", "HealthTech"
    ],
    "key_skills": [
        "GTM Strategy", "Product Management", "Data Analytics", "AI/ML Products",
        "Pre-sales", "Strategy & Operations", "Stakeholder Management",
        "Market Research", "Business Development", "Project Management",
        "SQL", "Python", "Power BI", "Tableau", "Technical Writing",
        "Cross-functional Leadership"
    ],
    "highlights": [
        "Led Project Denali: data analytics platform for a global sports conglomerate",
        "Built Chanakya: AI-powered HR platform with resume parsing and JD matching",
        "Developed AI Insurance Claim Assistant",
        "Owned full GTM strategy and pre-sales for B2B SaaS products",
        "Represented DevKraft at GITEX Dubai with live enterprise demos",
        "Co-founded Women's Development Cell, led gender equity initiatives",
        "MA Economics from IIFT with trade policy specialization"
    ],
    "preferred_company_stages": [
        "Series A to C startups", "VC-backed firms", "Unicorns",
        "Consulting firms", "Social sector organizations"
    ]
}

SCORING_WEIGHTS = {
    "role_fit": 30,
    "skill_overlap": 25,
    "industry_alignment": 18,
    "growth_signal": 15,
    "seniority_match": 12
}

# ═══════════════════════════════════════════════
# RULE-BASED SCORING ENGINE
# ═══════════════════════════════════════════════

ROLE_FIT_HIGH = [
    "chief of staff", "cos", "founder's office", "founder office",
    "entrepreneur in residence", "eir", "product manager", "associate product manager",
    "apm", "strategy", "strategy & operations", "strategy and operations",
    "growth manager", "growth lead", "vc analyst", "vc associate",
    "investment analyst", "venture capital", "management consultant",
    "business analyst", "program manager", "business operations",
    "general manager", "special projects", "strategic initiatives"
]
ROLE_FIT_MED = [
    "operations manager", "operations analyst", "project manager",
    "business development", "partnerships", "account manager",
    "marketing manager", "analyst", "associate", "consultant",
    "coordinator", "category manager", "product analyst"
]
ROLE_FIT_LOW = [
    "software engineer", "sde", "frontend developer", "backend developer",
    "full stack", "devops", "sre", "data engineer", "ml engineer",
    "machine learning engineer", "ui/ux designer", "graphic designer",
    "accountant", "hr manager", "recruiter", "legal", "compliance",
    "sales executive", "telesales", "customer support", "support engineer",
    "content writer", "copywriter", "seo specialist"
]

SKILL_CATEGORIES = {
    "gtm": ["gtm", "go to market", "go-to-market", "market entry", "launch strategy", "market strategy"],
    "product": ["product management", "product manager", "product strategy", "roadmap", "prd", "user stories", "agile", "scrum", "product lifecycle"],
    "data": ["data analytics", "data analysis", "analytics", "dashboard", "sql", "python", "power bi", "tableau", "metrics", "kpi", "reporting"],
    "ai_ml": ["ai", "artificial intelligence", "machine learning", "ml", "nlp", "llm", "generative ai", "deep learning"],
    "presales": ["pre-sales", "presales", "demo", "client facing", "client-facing", "rfp", "proposal", "solution selling"],
    "strategy": ["strategy", "strategic", "business strategy", "competitive analysis", "market research", "market sizing"],
    "stakeholder": ["stakeholder", "cross-functional", "cross functional", "c-suite", "ceo", "leadership", "executive"],
    "bizdev": ["business development", "partnerships", "bd", "alliances", "channel partner"],
    "project": ["project management", "program management", "pmo", "delivery", "execution", "timeline"],
    "technical": ["sql", "python", "api", "technical", "saas", "b2b", "enterprise software", "cloud"]
}

INDUSTRY_HIGH = ["ai", "artificial intelligence", "machine learning", "saas", "b2b", "enterprise",
    "deeptech", "deep tech", "venture capital", "vc", "fintech", "edtech",
    "healthtech", "consulting", "management consulting", "social impact", "development sector"]
INDUSTRY_MED = ["e-commerce", "ecommerce", "marketplace", "d2c", "consumer tech",
    "media", "gaming", "travel", "logistics", "supply chain", "agritech", "proptech", "insurtech"]
INDUSTRY_LOW = ["manufacturing", "automotive", "oil and gas", "mining", "construction",
    "real estate", "fmcg", "telecom", "government", "defence", "pharma", "bpo", "outsourcing"]

GROWTH_HIGH = ["series a", "series b", "series c", "seed", "pre-seed", "funded", "raised",
    "unicorn", "yc", "y combinator", "startup", "early stage", "early-stage",
    "fast growing", "fast-growing", "hypergrowth", "zero to one", "0 to 1",
    "greenfield", "founding team", "first hire", "building from scratch"]
GROWTH_MED = ["growth stage", "scale-up", "scaleup", "expanding", "growing team", "new vertical"]
GROWTH_LOW = ["mnc", "fortune 500", "large enterprise", "established", "government", "public sector"]

SENIORITY_POS = ["associate", "analyst", "junior", "entry level", "entry-level",
    "0-2 years", "1-3 years", "0-3 years", "1-2 years", "2-4 years",
    "fresher", "graduate", "early career", "early-career"]
SENIORITY_NEG = ["senior", "sr.", "lead", "principal", "staff", "director", "vp",
    "vice president", "head of", "c-level", "cto", "cfo",
    "5+ years", "7+ years", "8+ years", "10+ years", "15+ years"]
SENIORITY_MID = ["manager", "3-5 years", "2-5 years", "mid-level"]

ANTI_SKILLS = ["react", "angular", "vue.js", "java ", "c++", "rust", "kubernetes",
    "docker", "aws certified", "cisco", "networking", "chartered accountant",
    "ca ", "cpa", "nurse", "mbbs", "mechanical engineer"]


def _tier_score(text, high, med, low):
    t = text.lower()
    h = sum(1 for k in high if k in t)
    m = sum(1 for k in med if k in t)
    l = sum(1 for k in low if k in t)
    if h >= 3: return min(95, 75 + h * 5)
    if h >= 1: return min(88, 62 + h * 10)
    if m >= 2: return min(65, 40 + m * 8)
    if m >= 1: return 45
    if l >= 1: return max(10, 28 - l * 8)
    return 35


def score_role_fit(job):
    title = job.get("title", "").lower()
    desc = job.get("description", "").lower()
    th = sum(1 for k in ROLE_FIT_HIGH if k in title)
    tm = sum(1 for k in ROLE_FIT_MED if k in title)
    tl = sum(1 for k in ROLE_FIT_LOW if k in title)
    if th >= 1: return min(95, 78 + th * 7)
    if tm >= 1: return min(65, 45 + tm * 8)
    if tl >= 1: return max(5, 20 - tl * 8)
    dh = sum(1 for k in ROLE_FIT_HIGH if k in desc)
    if dh >= 2: return min(70, 50 + dh * 5)
    return 30


def score_skill_overlap(job):
    text = f"{job.get('title', '')} {job.get('description', '')}".lower()
    matches = sum(1 for cat, kws in SKILL_CATEGORIES.items() if any(k in text for k in kws))
    anti = sum(1 for k in ANTI_SKILLS if k in text)
    raw = (matches / len(SKILL_CATEGORIES)) * 100
    return min(100, max(0, int(raw - anti * 12)))


def score_industry(job):
    text = f"{job.get('company', '')} {job.get('title', '')} {job.get('description', '')}".lower()
    return _tier_score(text, INDUSTRY_HIGH, INDUSTRY_MED, INDUSTRY_LOW)


def score_growth(job):
    text = f"{job.get('company', '')} {job.get('description', '')}".lower()
    return _tier_score(text, GROWTH_HIGH, GROWTH_MED, GROWTH_LOW)


def score_seniority(job):
    text = f"{job.get('title', '')} {job.get('description', '')}".lower()
    p = sum(1 for k in SENIORITY_POS if k in text)
    n = sum(1 for k in SENIORITY_NEG if k in text)
    m = sum(1 for k in SENIORITY_MID if k in text)
    if n >= 2: return max(5, 25 - n * 8)
    if n == 1 and p == 0: return 30
    if p >= 2: return min(95, 75 + p * 5)
    if p >= 1: return 75
    if m >= 1: return 60
    return 50


def score_job(job):
    bd = {
        "role_fit": score_role_fit(job),
        "skill_overlap": score_skill_overlap(job),
        "industry_alignment": score_industry(job),
        "growth_signal": score_growth(job),
        "seniority_match": score_seniority(job)
    }
    total = round(bd["role_fit"]*0.30 + bd["skill_overlap"]*0.25 +
                  bd["industry_alignment"]*0.18 + bd["growth_signal"]*0.15 +
                  bd["seniority_match"]*0.12)

    parts = []
    if bd["role_fit"] >= 70: parts.append(f"Strong role fit: '{job['title']}' matches target roles")
    elif bd["role_fit"] <= 35: parts.append(f"Weak role fit: '{job['title']}' is outside target functions")
    if bd["skill_overlap"] >= 70: parts.append("High skill overlap with GTM, product, analytics, strategy capabilities")
    elif bd["skill_overlap"] <= 35: parts.append("Low skill overlap with candidate's profile")
    if bd["industry_alignment"] >= 70: parts.append(f"{job['company']} is in a preferred industry")
    if bd["growth_signal"] >= 70: parts.append("Strong growth signals: startup energy or funding")
    if bd["seniority_match"] <= 30: parts.append("Seniority mismatch: role likely needs more experience")
    if not parts: parts.append(f"Moderate fit for '{job['title']}' at {job['company']}")
    rationale = ". ".join(parts[:3]) + "."

    action = "apply" if total >= 75 else "email" if total >= 55 else "save" if total >= 35 else "skip"
    return {"total_score": total, "breakdown": bd, "rationale": rationale, "suggested_action": action}


# ═══════════════════════════════════════════════
# TEMPLATE EMAIL GENERATION
# ═══════════════════════════════════════════════

TEMPLATES = [
    {"subject": "Re: {title} at {company}",
     "body": "Hi,\n\nI came across the {title} role at {company} and wanted to reach out directly.\n\nI'm currently the APM and Chief of Staff at DevKraft Technologies, where I've led a data analytics platform for a global sports conglomerate and built AI products including an HR automation tool and an insurance claim assistant. I hold an MA in Economics from IIFT Delhi.\n\nWhat drew me to {company} is {hook}. The {title} role aligns well with my background in {skills}.\n\nWould love to have a quick conversation about how I could contribute. Happy to jump on a 15 minute call at your convenience.\n\nBest,\nAnkur"},
    {"subject": "{title} opportunity at {company}",
     "body": "Hi,\n\nWriting to express my interest in the {title} position at {company}.\n\nQuick context: I work as APM and Chief of Staff at a B2B SaaS company, where I own GTM strategy, product builds (AI HR platform, insurance claim assistant), and client-facing pre-sales. I've also led a data analytics platform for a global sports conglomerate and represented our company at GITEX Dubai. My background is MA Economics from IIFT.\n\n{company}'s work in {hook} resonates with what I've been building toward. My mix of {skills} would translate well here.\n\nOpen to connecting whenever works.\n\nCheers,\nAnkur"},
    {"subject": "Interested in {title} at {company}",
     "body": "Hi,\n\nI noticed the {title} opening at {company} and it caught my attention.\n\nAbout me: I run product and strategy at DevKraft Technologies as APM and Chief of Staff. My work spans AI product development, data analytics for enterprise clients, and full GTM execution for B2B SaaS. I hold an MA in Economics from IIFT Delhi.\n\n{hook} is exactly the kind of challenge I'm looking for. With my background in {skills}, I think there's a genuine fit.\n\nWould be great to chat if you're open to it.\n\nBest,\nAnkur"},
]


def _hook(job):
    d = job.get("description", "").lower()
    c = job.get("company", "")
    if any(w in d for w in ["ai", "artificial intelligence", "machine learning"]): return f"the AI-driven approach {c} is taking"
    if any(w in d for w in ["series a", "series b", "funded", "raised"]): return f"the growth trajectory at {c}"
    if any(w in d for w in ["0 to 1", "zero to one", "greenfield"]): return f"the zero-to-one building at {c}"
    if any(w in d for w in ["enterprise", "b2b", "saas"]): return f"the enterprise focus at {c}"
    if any(w in d for w in ["startup", "early stage"]): return f"the startup energy at {c}"
    if any(w in d for w in ["social impact", "mission"]): return f"the mission-driven work at {c}"
    return f"what {c} is building and the scope of this role"


def _skills(job):
    text = f"{job.get('title', '')} {job.get('description', '')}".lower()
    m = {
        "GTM strategy": ["gtm", "go to market", "market", "launch"],
        "product management": ["product", "roadmap", "agile"],
        "data analytics": ["data", "analytics", "sql", "dashboard"],
        "AI product development": ["ai", "machine learning", "ml", "llm"],
        "strategy and operations": ["strategy", "operations"],
        "pre-sales": ["pre-sales", "presales", "demo", "client"],
    }
    matched = [k for k, vs in m.items() if any(v in text for v in vs)]
    return ", ".join(matched[:3]) if matched else "strategy, product thinking, and data analytics"


def generate_email(job):
    t = random.choice(TEMPLATES)
    return {
        "subject": t["subject"].format(title=job.get("title",""), company=job.get("company","")),
        "body": t["body"].format(title=job.get("title",""), company=job.get("company",""),
                                 hook=_hook(job), skills=_skills(job))
    }


# ═══════════════════════════════════════════════
# JOB SOURCES — FREE APIs + OPTIONAL PAID
# ═══════════════════════════════════════════════

def _make_job(title, company, location, description, link, source, source_key, posted="", tags=None):
    jid = hashlib.md5(f"{title}{company}{source_key}".encode()).hexdigest()[:12]
    return {
        "id": jid, "title": title, "company": company,
        "location": location, "description": (description or "")[:2000],
        "posted": posted, "schedule": "",
        "link": link, "source": source, "source_key": source_key,
        "thumbnail": "", "extensions": tags or [],
        "score": None, "score_breakdown": None, "rationale": None,
        "suggested_action": None, "status": "new"
    }


def fetch_remotive(query, limit=50):
    """Remotive API — free, no key. Fetches all and filters client-side."""
    resp = http_requests.get("https://remotive.com/api/remote-jobs", params={
        "limit": limit
    }, timeout=15)
    resp.raise_for_status()
    ql = [w.lower() for w in query.split() if len(w) > 2]
    jobs = []
    for item in resp.json().get("jobs", []):
        text = f"{item.get('title','')} {item.get('company_name','')} {' '.join(item.get('tags',[]))} {item.get('description','')}".lower()
        if any(q in text for q in ql):
            jobs.append(_make_job(
                title=item.get("title", ""),
                company=item.get("company_name", ""),
                location=item.get("candidate_required_location", "Anywhere"),
                description=item.get("description", ""),
                link=item.get("url", ""),
                source="Remotive", source_key="remotive",
                posted=item.get("publication_date", "")[:10],
                tags=item.get("tags", [])
            ))
    return jobs


def fetch_arbeitnow(query, limit=100):
    """Arbeitnow API — free, no key. Fetches all and filters client-side."""
    resp = http_requests.get("https://www.arbeitnow.com/api/job-board-api", params={
        "per_page": limit
    }, timeout=15)
    resp.raise_for_status()
    ql = [w.lower() for w in query.split() if len(w) > 2]
    jobs = []
    for item in resp.json().get("data", []):
        text = f"{item.get('title','')} {item.get('company_name','')} {item.get('description','')} {' '.join(item.get('tags',[]))}".lower()
        if any(q in text for q in ql):
            jobs.append(_make_job(
                title=item.get("title", ""),
                company=item.get("company_name", ""),
                location=item.get("location", ""),
                description=item.get("description", ""),
                link=item.get("url", ""),
                source="Arbeitnow", source_key="arbeitnow",
                posted=datetime.datetime.fromtimestamp(item["created_at"]).strftime("%Y-%m-%d") if isinstance(item.get("created_at"), (int, float)) else str(item.get("created_at", ""))[:10],
                tags=item.get("tags", [])
            ))
    return jobs


def fetch_adzuna(query, location="india", limit=20):
    """Adzuna API — free tier, 250 calls/month. Needs ADZUNA_APP_ID + ADZUNA_APP_KEY."""
    app_id = os.getenv("ADZUNA_APP_ID")
    app_key = os.getenv("ADZUNA_APP_KEY")
    if not app_id or not app_key:
        raise ValueError("ADZUNA_APP_ID / ADZUNA_APP_KEY not set")
    country = "in" if "india" in location.lower() else "gb"
    resp = http_requests.get(f"https://api.adzuna.com/v1/api/jobs/{country}/search/1", params={
        "app_id": app_id, "app_key": app_key,
        "what": query, "results_per_page": limit,
        "content-type": "application/json"
    }, timeout=15)
    resp.raise_for_status()
    jobs = []
    for item in resp.json().get("results", []):
        jobs.append(_make_job(
            title=item.get("title", ""),
            company=item.get("company", {}).get("display_name", ""),
            location=item.get("location", {}).get("display_name", ""),
            description=item.get("description", ""),
            link=item.get("redirect_url", ""),
            source="Adzuna", source_key="adzuna",
            posted=item.get("created", "")[:10],
            tags=item.get("category", {}).get("label", "").split()
        ))
    return jobs


def fetch_jsearch(query, location="India", limit=10):
    """JSearch API (RapidAPI) — free tier 500/month. LinkedIn, Indeed, Glassdoor data."""
    key = os.getenv("JSEARCH_API_KEY")
    if not key:
        raise ValueError("JSEARCH_API_KEY not set")
    resp = http_requests.get("https://jsearch.p.rapidapi.com/search", params={
        "query": f"{query} in {location}",
        "num_pages": 1,
    }, headers={
        "X-RapidAPI-Key": key,
        "X-RapidAPI-Host": "jsearch.p.rapidapi.com"
    }, timeout=15)
    resp.raise_for_status()
    jobs = []
    for item in resp.json().get("data", []):
        src_name = item.get("job_publisher", "JSearch")
        src_key = src_name.lower().replace(" ", "_")
        jobs.append(_make_job(
            title=item.get("job_title", ""),
            company=item.get("employer_name", ""),
            location=f"{item.get('job_city','')}, {item.get('job_country','')}".strip(", "),
            description=item.get("job_description", ""),
            link=item.get("job_apply_link", "") or item.get("job_google_link", ""),
            source=src_name, source_key=f"jsearch_{src_key}",
            posted=item.get("job_posted_at_datetime_utc", "")[:10],
            tags=[item.get("job_employment_type", "")]
        ))
    return jobs


# ═══════════════════════════════════════════════
# SERPAPI (optional, needs key)
# ═══════════════════════════════════════════════

SERP_SOURCES = {
    "google_jobs": {"label": "Google Jobs", "site": "", "color": "#4285F4"},
    "linkedin": {"label": "LinkedIn", "site": "linkedin", "color": "#0A66C2"},
    "naukri": {"label": "Naukri", "site": "naukri", "color": "#4A90D9"},
    "indeed": {"label": "Indeed", "site": "indeed", "color": "#2164F3"},
    "iimjobs": {"label": "IIMJobs", "site": "iimjobs", "color": "#FF6B35"},
    "foundit": {"label": "Foundit", "site": "foundit", "color": "#6C5CE7"},
}

def fetch_serpapi(query, source_key, location="India", num=10):
    key = os.getenv("SERPAPI_KEY")
    if not key: raise ValueError("SERPAPI_KEY not set")
    src = SERP_SOURCES.get(source_key, {})
    q = f"{query} {src.get('site', '')}".strip()
    resp = http_requests.get("https://serpapi.com/search", params={
        "engine": "google_jobs", "q": q, "location": location,
        "api_key": key, "num": num, "hl": "en"
    }, timeout=30)
    resp.raise_for_status()
    jobs = []
    for item in resp.json().get("jobs_results", []):
        links = item.get("apply_options", [])
        jobs.append(_make_job(
            title=item.get("title", ""),
            company=item.get("company_name", ""),
            location=item.get("location", ""),
            description=item.get("description", ""),
            link=(links[0].get("link", "") if links else "") or item.get("share_link", ""),
            source=src.get("label", source_key), source_key=source_key,
            posted=item.get("detected_extensions", {}).get("posted_at", ""),
            tags=item.get("extensions", [])
        ))
    return jobs


# ═══════════════════════════════════════════════
# UNIFIED SEARCH
# ═══════════════════════════════════════════════

FREE_FETCHERS = {
    "remotive": fetch_remotive,
    "arbeitnow": fetch_arbeitnow,
}

KEYED_FETCHERS = {
    "adzuna": fetch_adzuna,
    "jsearch": fetch_jsearch,
}

ALL_SOURCES = {
    "remotive": {"label": "Remotive", "color": "#5850EC", "free": True},
    "arbeitnow": {"label": "Arbeitnow", "color": "#FF6B6B", "free": True},
    "adzuna": {"label": "Adzuna", "color": "#36B37E", "free": False},
    "jsearch": {"label": "JSearch", "color": "#F97316", "free": False},
    "google_jobs": {"label": "Google Jobs", "color": "#4285F4", "free": False},
    "linkedin": {"label": "LinkedIn", "color": "#0A66C2", "free": False},
    "naukri": {"label": "Naukri", "color": "#4A90D9", "free": False},
    "indeed": {"label": "Indeed", "color": "#2164F3", "free": False},
    "iimjobs": {"label": "IIMJobs", "color": "#FF6B35", "free": False},
    "foundit": {"label": "Foundit", "color": "#6C5CE7", "free": False},
}


def search_all(query, sources, location="India"):
    all_jobs, seen, errors = [], set(), {}
    for src in sources:
        try:
            if src in FREE_FETCHERS:
                fetched = FREE_FETCHERS[src](query)
            elif src in KEYED_FETCHERS:
                fetched = KEYED_FETCHERS[src](query, location)
            elif src in SERP_SOURCES:
                fetched = fetch_serpapi(query, src, location)
            else:
                continue
            for job in fetched:
                dk = f"{job['title'].lower().strip()}|{job['company'].lower().strip()}"
                if dk not in seen:
                    seen.add(dk)
                    all_jobs.append(job)
        except Exception as e:
            errors[src] = str(e)
    return all_jobs, errors


# ═══════════════════════════════════════════════
# GOOGLE AUTH (Gmail + Sheets)
# ═══════════════════════════════════════════════

def get_creds():
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    SCOPES = ["https://www.googleapis.com/auth/gmail.send", "https://www.googleapis.com/auth/spreadsheets"]
    creds = None
    tp = Path(__file__).parent / "token.json"
    cp = Path(__file__).parent / "credentials.json"
    if tp.exists(): creds = Credentials.from_authorized_user_file(str(tp), SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token: creds.refresh(Request())
        else:
            if not cp.exists(): raise FileNotFoundError("credentials.json not found in backend/")
            creds = InstalledAppFlow.from_client_secrets_file(str(cp), SCOPES).run_local_server(port=0)
        tp.write_text(creds.to_json())
    return creds


def gmail():
    from googleapiclient.discovery import build
    return build("gmail", "v1", credentials=get_creds())

def sheets():
    from googleapiclient.discovery import build
    return build("sheets", "v4", credentials=get_creds())


def send_email(to, subject, body):
    from email.mime.text import MIMEText
    msg = MIMEText(body); msg["to"] = to; msg["subject"] = subject
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    return gmail().users().messages().send(userId="me", body={"raw": raw}).execute()


def log_sheet(job, sd):
    sid = os.getenv("GOOGLE_SHEETS_ID")
    if not sid: raise ValueError("GOOGLE_SHEETS_ID not set")
    bd = sd.get("breakdown", {})
    row = [datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
           job.get("title",""), job.get("company",""), job.get("location",""),
           job.get("source",""), sd.get("total_score",""),
           bd.get("role_fit",""), bd.get("skill_overlap",""), bd.get("industry_alignment",""),
           bd.get("growth_signal",""), bd.get("seniority_match",""),
           sd.get("rationale",""), sd.get("suggested_action",""), job.get("link",""), job.get("status","")]
    sheets().spreadsheets().values().append(
        spreadsheetId=sid, range="Sheet1!A:O",
        valueInputOption="USER_ENTERED", insertDataOption="INSERT_ROWS",
        body={"values": [row]}).execute()


def init_headers():
    sid = os.getenv("GOOGLE_SHEETS_ID")
    if not sid: return
    r = sheets().spreadsheets().values().get(spreadsheetId=sid, range="Sheet1!A1:O1").execute()
    if not r.get("values"):
        sheets().spreadsheets().values().update(spreadsheetId=sid, range="Sheet1!A1:O1",
            valueInputOption="USER_ENTERED",
            body={"values": [["Timestamp","Title","Company","Location","Source","Score",
                "Role Fit","Skill Overlap","Industry","Growth","Seniority",
                "Rationale","Action","Link","Status"]]}).execute()


# ═══════════════════════════════════════════════
# NOTION
# ═══════════════════════════════════════════════

def notion_card(job, sd):
    from notion_client import Client
    n = Client(auth=os.getenv("NOTION_TOKEN"))
    dbid = os.getenv("NOTION_DATABASE_ID")
    if not dbid: raise ValueError("NOTION_DATABASE_ID not set")
    sc = sd.get("total_score", 0)
    st = "Hot Lead" if sc >= 75 else "Warm" if sc >= 50 else "Monitor"
    bd = sd.get("breakdown", {})
    # DB schema: Company (title), Role (rich_text), Link (rich_text), Status (status)
    return n.pages.create(
        parent={"database_id": dbid},
        properties={
            "Company": {"title": [{"text": {"content": job.get("company","")}}]},
            "Role": {"rich_text": [{"text": {"content": job.get("title","")}}]},
            "Link": {"rich_text": [{"text": {"content": job.get("link","")}}]},
        },
        children=[
            {"object":"block","type":"heading_2","heading_2":{"rich_text":[{"text":{"content":f"Score: {sc}/100 — {sd.get('suggested_action','save').upper()}"}}]}},
            {"object":"block","type":"paragraph","paragraph":{"rich_text":[{"text":{"content":sd.get("rationale","")}}]}},
            {"object":"block","type":"paragraph","paragraph":{"rich_text":[{"text":{"content":
                f"Role Fit: {bd.get('role_fit','N/A')} | Skills: {bd.get('skill_overlap','N/A')} | "
                f"Industry: {bd.get('industry_alignment','N/A')} | Growth: {bd.get('growth_signal','N/A')} | "
                f"Seniority: {bd.get('seniority_match','N/A')}"}}]}},
            {"object":"block","type":"paragraph","paragraph":{"rich_text":[{"text":{"content":
                f"Location: {job.get('location','')} | Source: {job.get('source','')}"}}]}},
        ]
    ).get("id", "")


# ═══════════════════════════════════════════════
# SLACK WEBHOOK
# ═══════════════════════════════════════════════

def send_slack(job, sd):
    url = os.getenv("SLACK_WEBHOOK_URL")
    if not url: raise ValueError("SLACK_WEBHOOK_URL not set")
    sc = sd.get("total_score", 0)
    bd = sd.get("breakdown", {})
    emoji = ":fire:" if sc >= 75 else ":large_yellow_circle:" if sc >= 50 else ":white_circle:"
    blocks = [
        {"type":"header","text":{"type":"plain_text","text":f"{emoji} {job.get('title','')} @ {job.get('company','')}"}},
        {"type":"section","fields":[
            {"type":"mrkdwn","text":f"*Score:* {sc}/100"},
            {"type":"mrkdwn","text":f"*Action:* {sd.get('suggested_action','—')}"},
            {"type":"mrkdwn","text":f"*Location:* {job.get('location','—')}"},
            {"type":"mrkdwn","text":f"*Source:* {job.get('source','—')}"},
        ]},
        {"type":"section","text":{"type":"mrkdwn","text":
            f"*Breakdown:* Role {bd.get('role_fit','—')} | Skills {bd.get('skill_overlap','—')} | "
            f"Industry {bd.get('industry_alignment','—')} | Growth {bd.get('growth_signal','—')} | "
            f"Seniority {bd.get('seniority_match','—')}"}},
        {"type":"section","text":{"type":"mrkdwn","text":f"_{sd.get('rationale','')}_"}},
    ]
    if job.get("link"):
        blocks.append({"type":"actions","elements":[
            {"type":"button","text":{"type":"plain_text","text":"View Job"},"url":job["link"],"style":"primary"}
        ]})
    resp = http_requests.post(url, json={"blocks": blocks}, timeout=10)
    resp.raise_for_status()
    return True


# ═══════════════════════════════════════════════
# ACTIVITY LOG
# ═══════════════════════════════════════════════

activity_log = []

def log_activity(action, job, detail=""):
    activity_log.insert(0, {
        "time": datetime.datetime.now().strftime("%H:%M:%S"),
        "action": action,
        "job_title": job.get("title", ""),
        "company": job.get("company", ""),
        "detail": detail
    })
    if len(activity_log) > 100:
        activity_log.pop()


from scoring_engine import evaluate_job

# ═══════════════════════════════════════════════
# ROUTES
# ═══════════════════════════════════════════════

job_store = {}

@app.route("/api/health")
def health(): return jsonify({"status": "ok", "timestamp": datetime.datetime.now().isoformat()})

@app.route("/api/profile")
def profile(): return jsonify({"profile": PROFILE, "weights": SCORING_WEIGHTS})

@app.route("/api/sources")
def api_sources():
    return jsonify({"sources": {k: {"label":v["label"],"color":v["color"],"free":v["free"]} for k,v in ALL_SOURCES.items()}})

@app.route("/api/search", methods=["POST"])
def api_search():
    d = request.json
    try:
        jobs, errs = search_all(
            d.get("query", "Product Manager AI"),
            d.get("sources", ["remotive", "remoteok", "arbeitnow"]),
            d.get("location", "India")
        )

        for j in jobs: job_store[j["id"]] = j
        log_activity("search", {"title": d.get("query",""), "company": ""}, f"{len(jobs)} results from {len(d.get('sources',[]))} sources")
        return jsonify({"jobs": jobs, "count": len(jobs), "errors": errs})
    except Exception as e: return jsonify({"error": str(e)}), 500

@app.route("/api/score", methods=["POST"])
def api_score():
    if "resume" in request.files:
        file = request.files["resume"]
        job_str = request.form.get("job")
        if not job_str: return jsonify({"error": "Job missing"}), 400
        import json
        job = json.loads(job_str)
        try:
            resume_text = ""
            if file.filename.endswith(".pdf"):
                import PyPDF2
                reader = PyPDF2.PdfReader(file)
                for page in reader.pages: resume_text += page.extract_text() + " "
            else:
                resume_text = file.read().decode("utf-8", errors="ignore")
            r = evaluate_job(job, resume_text)
            job.update({"score":r["score"],"score_breakdown":r["breakdown"],
                        "rationale": f"12-Dimension algorithmic grading applied.", "suggested_action":r["suggested_action"]})
            if job.get("id"): job_store[job["id"]] = job
            log_activity("scored_dynamic", job, f"Score: {r['score']}")
            return jsonify({"score": r, "job": job})
        except Exception as e: return jsonify({"error": str(e)}), 500

    d = request.json
    job = d.get("job") or job_store.get(d.get("job_id"))
    if not job: return jsonify({"error": "Job not found"}), 404
    try:
        r = score_job(job)
        job.update({"score":r["total_score"],"score_breakdown":r["breakdown"],
                     "rationale":r["rationale"],"suggested_action":r["suggested_action"]})
        if d.get("job_id"): job_store[d["job_id"]] = job
        log_activity("scored", job, f"Score: {r['total_score']}")
        return jsonify({"score": r, "job": job})
    except Exception as e: return jsonify({"error": str(e)}), 500

@app.route("/api/email/generate", methods=["POST"])
def api_gen_email():
    d = request.json
    job = d.get("job") or job_store.get(d.get("job_id"))
    if not job: return jsonify({"error": "Job not found"}), 404
    return jsonify({"email": generate_email(job)})

@app.route("/api/email/send", methods=["POST"])
def api_send_email():
    d = request.json
    if not all([d.get("to"), d.get("subject"), d.get("body")]): return jsonify({"error": "Missing fields"}), 400
    try:
        r = send_email(d["to"], d["subject"], d["body"])
        log_activity("emailed", {"title": d.get("subject",""), "company": d.get("to","")}, f"To: {d['to']}")
        return jsonify({"sent": True, "message_id": r.get("id")})
    except Exception as e: return jsonify({"error": str(e)}), 500

@app.route("/api/sheets/log", methods=["POST"])
def api_log_sheet():
    d = request.json
    job = d.get("job") or job_store.get(d.get("job_id"))
    if not job: return jsonify({"error": "Job not found"}), 404
    sd = d.get("score_data") or {"total_score":job.get("score"),"breakdown":job.get("score_breakdown",{}),
         "rationale":job.get("rationale",""),"suggested_action":job.get("suggested_action","")}
    try:
        log_sheet(job, sd); job["status"]="logged"
        log_activity("sheet_logged", job)
        return jsonify({"logged":True})
    except Exception as e: return jsonify({"error": str(e)}), 500

@app.route("/api/sheets/log-all", methods=["POST"])
def api_log_all():
    logged, errs = 0, []
    for jid, job in job_store.items():
        if job.get("score") is not None:
            try:
                sd = {"total_score":job["score"],"breakdown":job.get("score_breakdown",{}),"rationale":job.get("rationale",""),"suggested_action":job.get("suggested_action","")}
                log_sheet(job, sd); job["status"]="logged"; logged += 1
            except Exception as e: errs.append({"id":jid,"error":str(e)})
    return jsonify({"logged":logged,"errors":errs})

@app.route("/api/sheets/init", methods=["POST"])
def api_init(): init_headers(); return jsonify({"ok":True})

@app.route("/api/notion/create", methods=["POST"])
def api_notion():
    d = request.json
    job = d.get("job") or job_store.get(d.get("job_id"))
    if not job: return jsonify({"error":"Job not found"}), 404
    sd = d.get("score_data") or {"total_score":job.get("score",0),"breakdown":job.get("score_breakdown",{}),"rationale":job.get("rationale",""),"suggested_action":job.get("suggested_action","")}
    try:
        pid = notion_card(job, sd); job["status"]="tracked"
        log_activity("notion_created", job, f"Page: {pid}")
        return jsonify({"created":True,"page_id":pid})
    except Exception as e: return jsonify({"error":str(e)}), 500

@app.route("/api/slack/notify", methods=["POST"])
def api_slack():
    d = request.json
    job = d.get("job") or job_store.get(d.get("job_id"))
    if not job: return jsonify({"error":"Job not found"}), 404
    sd = d.get("score_data") or {"total_score":job.get("score",0),"breakdown":job.get("score_breakdown",{}),"rationale":job.get("rationale",""),"suggested_action":job.get("suggested_action","")}
    try:
        send_slack(job, sd)
        log_activity("slack_notified", job)
        return jsonify({"sent":True})
    except Exception as e: return jsonify({"error":str(e)}), 500

@app.route("/api/connectors/status")
def api_connectors():
    return jsonify({"connectors":{
        "remotive": True,
        "arbeitnow": True,
        "adzuna": bool(os.getenv("ADZUNA_APP_ID")) and bool(os.getenv("ADZUNA_APP_KEY")),
        "jsearch": bool(os.getenv("JSEARCH_API_KEY")),
        "serpapi": bool(os.getenv("SERPAPI_KEY")),
        "gmail": Path(Path(__file__).parent/"credentials.json").exists(),
        "sheets": bool(os.getenv("GOOGLE_SHEETS_ID")),
        "notion": bool(os.getenv("NOTION_TOKEN")) and bool(os.getenv("NOTION_DATABASE_ID")),
        "slack": bool(os.getenv("SLACK_WEBHOOK_URL")),
    }})

@app.route("/api/jobs")
def api_jobs():
    return jsonify({"jobs":sorted(job_store.values(),key=lambda j:j.get("score") or -1,reverse=True)})

@app.route("/api/activity")
def api_activity():
    return jsonify({"log": activity_log[:30]})

@app.route("/api/stats")
def api_stats():
    all_j = list(job_store.values())
    scored = [j for j in all_j if j.get("score") is not None]
    return jsonify({
        "total": len(all_j),
        "scored": len(scored),
        "avg_score": round(sum(j["score"] for j in scored)/max(len(scored),1)) if scored else 0,
        "hot_leads": len([j for j in scored if j["score"] >= 75]),
        "actions": {"apply": len([j for j in scored if j.get("suggested_action")=="apply"]),
                     "email": len([j for j in scored if j.get("suggested_action")=="email"]),
                     "save": len([j for j in scored if j.get("suggested_action")=="save"]),
                     "skip": len([j for j in scored if j.get("suggested_action")=="skip"])},
        "sources": {},
        "activity_count": len(activity_log)
    })


if __name__ == "__main__":
    app.run(debug=True, port=5001)
