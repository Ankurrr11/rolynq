# backend/scoring_engine.py
import re
from scoring_rules import *

def extract_words(text):
    return set(re.findall(r'\b[a-zA-Z]{4,}\b', str(text).lower()))

def count_matches(text, word_list):
    return sum(1 for w in word_list if re.search(r'\b' + re.escape(w.lower()) + r'\b', text.lower()))

def evaluate_job(job, resume_text):
    if not resume_text: return {"score": 0, "breakdown": {}, "suggested_action": "skip"}
    
    t_res = resume_text.lower()
    t_job = (str(job.get("title", "")) + " " + str(job.get("description", ""))).lower()
    
    w_res = extract_words(t_res)
    w_job = extract_words(t_job)
    
    scores = {}

    # D1. Keyword Match (14%)
    overlap = len(w_res.intersection(w_job))
    scores["keyword_match"] = min(100, int((overlap / 40.0) * 100))

    # D2. Semantic Match (15%)
    sem_count = 0
    for cat, syns in SYNONYMS.items():
        if count_matches(t_res, syns) > 0 and count_matches(t_job, syns) > 0:
            sem_count += 1
    scores["semantic_match"] = min(100, int((sem_count / max(1, len(SYNONYMS))) * 100))

    # D3. Functional Overlap (13%)
    func_count = sum(1 for k, v in FUNCTIONAL_BUCKETS.items() if count_matches(t_res, v) > 0 and count_matches(t_job, v) > 0)
    scores["functional_overlap"] = min(100, int((func_count / 3.0) * 100)) # 3 buckets = 100

    # D4. Seniority Calibration (10%)
    high = count_matches(t_job, SENIORITY_INDICATORS["high"])
    low = count_matches(t_job, SENIORITY_INDICATORS["low"])
    if high > 0: scores["seniority_match"] = 20
    elif low > 0: scores["seniority_match"] = 40
    else: scores["seniority_match"] = 90

    # D5. Output Deliverables (10%)
    out_count = sum(1 for k, v in OUTPUT_TYPES.items() if count_matches(t_job, v) > 0)
    scores["output_match"] = min(100, out_count * 35)

    # D6. Authority Verbs (9%)
    hi_auth = count_matches(t_job, AUTHORITY_VERBS["high"])
    lo_auth = count_matches(t_job, AUTHORITY_VERBS["low"])
    scores["authority_score"] = min(100, max(0, 50 + (hi_auth * 15) - (lo_auth * 15)))

    # D7. Archetype Fit (9%)
    if count_matches(t_job, COMPANY_ARCHETYPES["seed"]) > 0: scores["archetype_fit"] = 100
    elif count_matches(t_job, COMPANY_ARCHETYPES["scaling"]) > 0: scores["archetype_fit"] = 80
    elif count_matches(t_job, COMPANY_ARCHETYPES["corporate"]) > 0: scores["archetype_fit"] = 20
    else: scores["archetype_fit"] = 55

    # D8. Industry Adjacency (8%)
    if count_matches(t_job, INDUSTRIES["highest"]) > 0: scores["industry_adjacency"] = 100
    elif count_matches(t_job, INDUSTRIES["medium"]) > 0: scores["industry_adjacency"] = 70
    elif count_matches(t_job, INDUSTRIES["lowest"]) > 0: scores["industry_adjacency"] = 20
    else: scores["industry_adjacency"] = 60

    # D9. Founder Language Ratio (7%)
    fl = count_matches(t_job, FOUNDER_LANGUAGE)
    hr = count_matches(t_job, HR_LANGUAGE)
    if hr == 0 and fl == 0: scores["founder_language"] = 50
    elif fl > hr: scores["founder_language"] = 90
    else: scores["founder_language"] = 30

    # D10. Timing Score (6%)
    scores["timing_score"] = 85 # Assuming fresh API fetches

    # D11. Learning Curve (5%)
    ratio = overlap / max(1, len(w_job))
    if ratio > 0.8: scores["learning_curve"] = 40
    elif ratio < 0.2: scores["learning_curve"] = 30
    else: scores["learning_curve"] = 95

    # D12. Geo-Mobility (4%)
    loc = str(job.get("location", "")).lower()
    if "india" in loc or "remote" in loc: scores["geo_mobility"] = 100
    else: scores["geo_mobility"] = 60
    
    # Calculate Final Weighted Score
    final = 0
    for dim, val in scores.items():
        w = WEIGHTS.get(dim, 0) / 100.0
        final += val * w
        
    fs = int(final)
    action = "apply" if fs >= 75 else "email" if fs >= 55 else "save" if fs >= 35 else "skip"
    
    return {
        "score": fs,
        "suggested_action": action,
        "breakdown": scores
    }
