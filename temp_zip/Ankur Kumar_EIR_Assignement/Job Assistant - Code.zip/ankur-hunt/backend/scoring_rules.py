# backend/scoring_rules.py

"""D1/D2: Semantic Skill Matching"""
SYNONYMS = {
    "gtm": ["gtm", "go to market", "go-to-market", "market entry", "launch strategy", "scaling", "growth"],
    "product": ["product management", "prd", "user stories", "roadmap", "agile", "wireframes", "pm"],
    "data": ["sql", "python", "power bi", "tableau", "analytics", "dashboard", "metrics", "kpi", "data analysis"],
    "ai_ml": ["genai", "generative ai", "llm", "machine learning", "nlp", "artificial intelligence", "deep learning", "ai"],
    "bizdev": ["business development", "partnerships", "sales", "alliances", "client facing", "pre-sales"]
}

"""D3: Functional Buckets Map"""
FUNCTIONAL_BUCKETS = {
    "product": ["product", "roadmap", "user", "ux", "launch"],
    "operations": ["operations", "process", "efficiency", "execution", "logistics", "supply chain"],
    "strategy": ["strategy", "research", "market", "sizing", "competitive analyst", "consulting"],
    "growth": ["growth", "marketing", "acquisition", "retention", "conversion", "sales"]
}

"""D4: Seniority & Reporting"""
SENIORITY_INDICATORS = {
    "high": ["director", "vp", "c-level", "head of", "lead a team of", "principal", "report to the board", "10+ years", "15+ years"],
    "mid": ["manager", "lead", "manage a team", "own the roadmap", "end-to-end", "3-5 years", "2-4 years"],
    "low": ["junior", "associate", "entry level", "fresher", "intern", "coordinate", "support the team", "0-2 years"]
}

"""D5: Output Deliverables"""
OUTPUT_TYPES = {
    "specs": ["spec", "prd", "requirement", "user story", "wireframe"],
    "presentations": ["deck", "presentation", "narrative", "pitch", "proposal"],
    "analysis": ["dashboard", "model", "pipeline", "etl", "query", "report"]
}

"""D6: Authority Verbs"""
AUTHORITY_VERBS = {
    "high": ["own", "lead", "define", "build", "decide", "drive", "architect", "spearhead", "pioneer", "oversee"],
    "low": ["support", "assist", "coordinate", "help", "execute under", "maintain", "participate", "collaborate"]
}

"""D7: Archetype Maturity"""
COMPANY_ARCHETYPES = {
    "seed": ["seed", "pre-seed", "founding team", "first hire", "zero to one", "0 to 1", "early-stage", "stealth"],
    "scaling": ["series a", "series b", "series c", "growth stage", "scale-up", "scaleup"],
    "corporate": ["fortune 500", "mnc", "enterprise", "public sector", "government", "established"]
}

"""D8: Industry Maps (Adjacency fallback assumes 60, exact match assumes 100)"""
INDUSTRIES = {
    "highest": ["ai", "saas", "b2b", "deep tech", "venture capital", "fintech", "edtech", "healthtech"],
    "medium": ["marketplace", "d2c", "e-commerce", "ecommerce", "media", "gaming", "consumer"],
    "lowest": ["manufacturing", "telecom", "bpo", "automotive", "mining", "defence", "outsourcing"]
}

"""D9: Founder Language Ratio"""
FOUNDER_LANGUAGE = ["wear many hats", "zero to one", "figure things out", "scrappy", "move fast", "ambiguous", "hustle", "ownership"]
HR_LANGUAGE = ["collaborate cross-functionally", "drive alignment", "stakeholder management", "best practices", "process-driven", "synergy"]

"""Weights Definition (Must == 100)"""
WEIGHTS = {
    "keyword_match": 14,
    "semantic_match": 15,
    "functional_overlap": 13,
    "seniority_match": 10,
    "output_match": 10,
    "authority_score": 9,
    "archetype_fit": 9,
    "industry_adjacency": 8,
    "founder_language": 7,
    "timing_score": 6,
    "learning_curve": 5,
    "geo_mobility": 4
}
