import React, { useState, useEffect } from 'react'
import {
  Search, Mail, FileSpreadsheet, Layout, CheckCircle,
  ChevronDown, ChevronUp, ExternalLink, Send, Loader2,
  Target, ArrowUpDown, Briefcase, MapPin, TrendingUp, Brain,
  AlertCircle, BarChart3, Compass, Clock, Sparkles, X,
  Activity, Zap, Globe, MessageSquare, Hash
} from 'lucide-react'

const API = '/api'

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#F8FAFC;--bg2:#FFFFFF;--surface:#FFFFFF;--surface2:#F1F5F9;--surface3:#E2E8F0;
  --border:#E2E8F0;--border2:#CBD5E1;--border3:#94A3B8;
  --text:#0F172A;--text2:#334155;--text3:#475569;--text4:#64748B;
  --accent:#005F4B;--accent2:#047857;--accent-bg:rgba(0,95,75,.08);--accent-bd:rgba(0,95,75,.2);
  --green:#059669;--green-bg:rgba(5,150,105,.1);--green-bd:rgba(5,150,105,.25);
  --orange:#D97706;--orange-bg:rgba(217,119,6,.1);--orange-bd:rgba(217,119,6,.25);
  --red:#DC2626;--red-bg:rgba(220,38,38,.1);--red-bd:rgba(220,38,38,.25);
  --blue:#2563EB;--blue-bg:rgba(37,99,235,.1);--blue-bd:rgba(37,99,235,.25);
  --purple:#7C3AED;--purple-bg:rgba(124,58,237,.1);--purple-bd:rgba(124,58,237,.25);
  --cyan:#0891B2;--cyan-bg:rgba(8,145,178,.1);--cyan-bd:rgba(8,145,178,.25);
  --font:'Inter',-apple-system,sans-serif;--mono:'JetBrains Mono',monospace;
  --r:4px;--rs:4px;
}
body{font-family:var(--font);background:var(--bg);color:var(--text);line-height:1.5;-webkit-font-smoothing:antialiased;letter-spacing:-0.015em;}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}
input,textarea,select{font-family:var(--font);background:var(--surface);border:1px solid var(--border);color:var(--text);border-radius:var(--rs);padding:8px 12px;font-size:13px;outline:none;transition:all .2s}
input:focus,textarea:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}
textarea{resize:vertical;min-height:140px;line-height:1.6}
@keyframes fadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
@keyframes slideIn{from{opacity:0;transform:translateX(-8px)}to{opacity:1;transform:translateX(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
.fi{animation:fadeIn .3s ease-out forwards}
.si{animation:slideIn .3s ease-out forwards}
.sp{animation:spin .7s linear infinite}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
`

function Badge({children, color='default', dot, style:s={}}){
  const T={
    default:{bg:'var(--surface2)',c:'var(--text2)',bd:'var(--border)'},
    accent:{bg:'var(--accent-bg)',c:'var(--accent2)',bd:'var(--accent-bd)'},
    green:{bg:'var(--green-bg)',c:'var(--green)',bd:'var(--green-bd)'},
    orange:{bg:'var(--orange-bg)',c:'var(--orange)',bd:'var(--orange-bd)'},
    red:{bg:'var(--red-bg)',c:'var(--red)',bd:'var(--red-bd)'},
    blue:{bg:'var(--blue-bg)',c:'var(--blue)',bd:'var(--blue-bd)'},
    purple:{bg:'var(--purple-bg)',c:'var(--purple)',bd:'var(--purple-bd)'},
    cyan:{bg:'var(--cyan-bg)',c:'var(--cyan)',bd:'var(--cyan-bd)'},
  }
  const t=T[color]||T.default
  return <span style={{display:'inline-flex',alignItems:'center',gap:5,background:t.bg,color:t.c,border:`1px solid ${t.bd}`,borderRadius:20,padding:'2px 9px',fontSize:10.5,fontWeight:600,letterSpacing:'.02em',whiteSpace:'nowrap',...s}}>
    {dot&&<span style={{width:5,height:5,borderRadius:'50%',background:t.c}}/>}
    {children}
  </span>
}

function Btn({children, variant='primary', loading, icon:I, small, ...p}){
  const base={display:'inline-flex',alignItems:'center',gap:6,padding:small?'5px 10px':'7px 14px',borderRadius:'var(--rs)',fontSize:small?11.5:12.5,fontWeight:500,fontFamily:'var(--font)',cursor:loading?'wait':p.disabled?'not-allowed':'pointer',transition:'all .15s',opacity:p.disabled?.4:1,border:'none',letterSpacing:'.01em'}
  const V={
    primary:{...base,background:'var(--accent)',color:'#fff'},
    secondary:{...base,background:'var(--surface2)',color:'var(--text)',border:'1px solid var(--border)'},
    ghost:{...base,background:'transparent',color:'var(--text2)'},
    soft:{...base,background:'var(--accent-bg)',color:'var(--accent2)',border:'1px solid var(--accent-bd)'},
  }
  return <button {...p} disabled={loading||p.disabled} style={{...V[variant],...p.style}}>
    {loading?<Loader2 size={small?11:13} className="sp"/>:I&&<I size={small?11:13}/>}{children}
  </button>
}

function ScoreRing({score, size=48}){
  if(score==null) return <div style={{width:size,height:size,borderRadius:'50%',border:'1.5px dashed var(--border2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,color:'var(--text4)',fontFamily:'var(--mono)'}}>--</div>
  const c=score>=75?'var(--green)':score>=50?'var(--orange)':'var(--red)'
  const bg=score>=75?'var(--green-bg)':score>=50?'var(--orange-bg)':'var(--red-bg)'
  const r=(size-6)/2, circ=2*Math.PI*r, off=circ-(score/100)*circ
  return <div style={{position:'relative',width:size,height:size}}>
    <svg width={size} height={size} style={{transform:'rotate(-90deg)'}}>
      <circle cx={size/2} cy={size/2} r={r} fill={bg} stroke="var(--border)" strokeWidth="2"/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={c} strokeWidth="2" strokeDasharray={circ} strokeDashoffset={off} strokeLinecap="round" style={{transition:'stroke-dashoffset .8s ease-out'}}/>
    </svg>
    <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:size>40?14:11,fontWeight:600,color:c}}>{score}</div>
  </div>
}

function CBar({label, score, icon:I, weight}){
  const c=score>=75?'var(--green)':score>=50?'var(--orange)':'var(--red)'
  return <div style={{display:'flex',alignItems:'center',gap:8,padding:'3px 0'}}>
    <I size={12} style={{color:'var(--text4)',flexShrink:0}}/>
    <span style={{fontSize:11.5,color:'var(--text3)',width:65,flexShrink:0}}>{label}</span>
    <div style={{flex:1,height:4,background:'var(--surface)',borderRadius:2,overflow:'hidden'}}>
      <div style={{width:`${score}%`,height:'100%',background:c,borderRadius:2,transition:'width .6s ease-out'}}/>
    </div>
    <span style={{fontFamily:'var(--mono)',fontSize:11,fontWeight:600,color:c,width:22,textAlign:'right'}}>{score}</span>
    <span style={{fontSize:9.5,color:'var(--text4)',fontFamily:'var(--mono)',width:26}}>{weight}%</span>
  </div>
}

function Breakdown({breakdown:bd, rationale}){
  if(!bd) return null
  const items=[{k:'role_fit',l:'Role Fit',i:Target,w:30},{k:'skill_overlap',l:'Skills',i:Brain,w:25},{k:'industry_alignment',l:'Industry',i:Briefcase,w:18},{k:'growth_signal',l:'Growth',i:TrendingUp,w:15},{k:'seniority_match',l:'Seniority',i:ArrowUpDown,w:12}]
  return <div style={{background:'var(--surface)',borderRadius:'var(--rs)',padding:'12px 14px',marginTop:12,border:'1px solid var(--border)'}} className="fi">
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1px 16px'}}>
      {items.map(x=><CBar key={x.k} label={x.l} score={bd[x.k]} icon={x.i} weight={x.w}/>)}
    </div>
    {rationale&&<p style={{fontSize:11.5,color:'var(--text3)',lineHeight:1.6,borderTop:'1px solid var(--border)',paddingTop:10,marginTop:10}}>{rationale}</p>}
  </div>
}

function EmailModal({job, onClose}){
  const [loading,setLoading]=useState(true),[sending,setSending]=useState(false),[sent,setSent]=useState(false)
  const [to,setTo]=useState(job.recruiter_email || ''),[subj,setSubj]=useState(''),[body,setBody]=useState('')
  useEffect(()=>{fetch(`${API}/email/generate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job})}).then(r=>r.json()).then(d=>{setSubj(d.email.subject);setBody(d.email.body);setLoading(false)}).catch(()=>setLoading(false))},[])
  const send=async()=>{if(!to)return;setSending(true);try{await fetch(`${API}/email/send`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({to,subject:subj,body})});setSent(true)}catch(e){console.error(e)}setSending(false)}
  return <div style={{position:'fixed',inset:0,background:'rgba(15,23,42,.4)',backdropFilter:'blur(4px)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000}} onClick={onClose}>
    <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:12,padding:24,width:540,boxShadow:'0 10px 25px rgba(0,0,0,.05)',maxHeight:'85vh',overflow:'auto'}} onClick={e=>e.stopPropagation()} className="fi">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:34,height:34,borderRadius:8,background:'var(--blue-bg)',border:'1px solid var(--blue-bd)',display:'flex',alignItems:'center',justifyContent:'center'}}><Mail size={15} style={{color:'var(--blue)'}}/></div>
          <div><h3 style={{fontSize:14,fontWeight:600}}>Cold Outreach</h3><p style={{fontSize:11,color:'var(--text3)'}}>{job.company}</p></div>
        </div>
        <button onClick={onClose} style={{background:'var(--surface)',border:'1px solid var(--border)',width:28,height:28,borderRadius:6,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={13} style={{color:'var(--text3)'}}/></button>
      </div>
      {loading?<div style={{textAlign:'center',padding:48,color:'var(--text3)'}}><Loader2 size={18} className="sp"/><p style={{fontSize:12,marginTop:10}}>Generating personalized email...</p></div>
      :sent?<div style={{textAlign:'center',padding:48}}>
          <div style={{width:48,height:48,borderRadius:'50%',background:'var(--green-bg)',border:'1px solid var(--green-bd)',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 14px'}}><CheckCircle size={22} style={{color:'var(--green)'}}/></div>
          <p style={{fontSize:15,fontWeight:600,color:'var(--green)'}}>Email Sent</p>
          <p style={{fontSize:12,color:'var(--text3)',marginTop:4}}>Delivered to {to}</p>
        </div>
      :<div style={{display:'flex',flexDirection:'column',gap:12}}>
          <div><label style={{fontSize:11,color:'var(--text3)',marginBottom:4,display:'block',fontWeight:500,letterSpacing:'.03em'}}>RECIPIENT</label><input value={to} onChange={e=>setTo(e.target.value)} placeholder="hiring@company.com" style={{width:'100%'}}/></div>
          <div><label style={{fontSize:11,color:'var(--text3)',marginBottom:4,display:'block',fontWeight:500,letterSpacing:'.03em'}}>SUBJECT</label><input value={subj} onChange={e=>setSubj(e.target.value)} style={{width:'100%'}}/></div>
          <div><label style={{fontSize:11,color:'var(--text3)',marginBottom:4,display:'block',fontWeight:500,letterSpacing:'.03em'}}>BODY</label><textarea value={body} onChange={e=>setBody(e.target.value)} style={{width:'100%'}}/></div>
          <div style={{display:'flex',gap:8,justifyContent:'flex-end',paddingTop:4}}>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn onClick={send} loading={sending} icon={Send}>Send via Gmail</Btn>
          </div>
        </div>}
    </div>
  </div>
}

function ScoreModal({job, onClose, onScored}){
  const [file,setFile]=useState(null),[scoring,setScoring]=useState(false),[err,setErr]=useState('')
  const score=async()=>{
    if(!file) return setErr('Please select a resume file (.pdf or .txt)')
    setScoring(true);setErr('')
    try{
      const fd = new FormData();
      fd.append('resume', file)
      fd.append('job', JSON.stringify(job))
      const r = await fetch(`${API}/score`,{method:'POST',body:fd})
      const d = await r.json()
      if(d.error) throw new Error(d.error)
      onScored(d.job, file)
    }catch(e){setErr(e.message)}
    setScoring(false)
  }
  return <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.6)',backdropFilter:'blur(12px)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000}} onClick={onClose}>
    <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:12,padding:24,width:440,boxShadow:'0 24px 80px rgba(0,0,0,.5)'}} onClick={e=>e.stopPropagation()} className="fi">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:34,height:34,borderRadius:8,background:'var(--accent-bg)',border:'1px solid var(--accent-bd)',display:'flex',alignItems:'center',justifyContent:'center'}}><Sparkles size={15} style={{color:'var(--accent)'}}/></div>
          <div><h3 style={{fontSize:14,fontWeight:600}}>Dynamic Resume Match</h3><p style={{fontSize:11,color:'var(--text3)'}}>Upload resume to score fit</p></div>
        </div>
        <button onClick={onClose} style={{background:'var(--surface)',border:'1px solid var(--border)',width:28,height:28,borderRadius:6,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={13} style={{color:'var(--text3)'}}/></button>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div style={{border:'2px dashed var(--border)',borderRadius:8,padding:'32px 10px',textAlign:'center',background:file?'var(--surface)':'transparent'}}>
          <input type="file" onChange={e=>setFile(e.target.files[0])} accept=".pdf,.txt" style={{display:'block',margin:'0 auto',fontSize:12,color:'var(--text3)'}} />
        </div>
        {err&&<p style={{fontSize:12,color:'var(--red)',textAlign:'center'}}>{err}</p>}
        <div style={{display:'flex',gap:8,justifyContent:'flex-end',paddingTop:4}}>
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn onClick={score} loading={scoring} icon={Sparkles}>Generate Score</Btn>
        </div>
      </div>
    </div>
  </div>
}

function GlobalResumeModal({onClose, onSet}){
  const [file,setFile]=useState(null)
  return <div style={{position:'fixed',inset:0,background:'rgba(15,23,42,.4)',backdropFilter:'blur(4px)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:2000}} onClick={onClose}>
    <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:12,padding:24,width:440,boxShadow:'0 10px 25px rgba(0,0,0,.05)'}} onClick={e=>e.stopPropagation()} className="fi">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:34,height:34,borderRadius:8,background:'var(--accent-bg)',border:'1px solid var(--accent-bd)',display:'flex',alignItems:'center',justifyContent:'center'}}><Sparkles size={15} style={{color:'var(--accent)'}}/></div>
          <div><h3 style={{fontSize:14,fontWeight:600}}>Resume Synchronization</h3><p style={{fontSize:11,color:'var(--text3)'}}>Upload once, score all jobs instantly</p></div>
        </div>
        <button onClick={onClose} style={{background:'var(--surface)',border:'1px solid var(--border)',width:28,height:28,borderRadius:6,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={13} style={{color:'var(--text3)'}}/></button>
      </div>
      <div style={{border:'2px dashed var(--border)',borderRadius:8,padding:'32px 10px',textAlign:'center',background:file?'var(--surface)':'transparent'}}>
        <input type="file" onChange={e=>{
          const f=e.target.files[0];
          if(f){ onSet(f); onClose() }
        }} accept=".pdf,.txt" style={{display:'block',margin:'0 auto',fontSize:12,color:'var(--text3)'}} />
      </div>
      <p style={{textAlign:'center',fontSize:11,color:'var(--text4)',marginTop:12}}>This resume will be securely used to instantly grade incoming jobs.</p>
    </div>
  </div>
}


function JobCard({job, onScore, onEmail, onLogSheet, onNotion, onSlack, scoring, connectors}){
  const [exp,setExp]=useState(false),[acts,setActs]=useState({})
  const ac={apply:'green',email:'blue',save:'orange',skip:'default'}
  const recEmail = job.description?.match(/[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}/)?.[0]
  
  return <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:'var(--r)',padding:'16px 18px',transition:'all .2s',boxShadow:'0 2px 4px rgba(0,0,0,.02)'}} className="fi job-card">
    <div style={{display:'flex',gap:14,alignItems:'flex-start'}}>
      <div style={{flexShrink:0,paddingTop:2}}><ScoreRing score={job.score}/></div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:8,marginBottom:6}}>
          <h3 style={{fontSize:14,fontWeight:600,lineHeight:1.3}}>{job.title}</h3>
          <div style={{display:'flex',gap:4,flexShrink:0}}>
            {job.link&&<a href={job.link} target="_blank" rel="noopener" style={{display:'inline-flex',alignItems:'center',justifyContent:'center',width:26,height:26,borderRadius:6,background:'var(--surface)',border:'1px solid var(--border)',color:'var(--text3)',textDecoration:'none'}}><ExternalLink size={11}/></a>}
            <button onClick={()=>setExp(!exp)} style={{display:'inline-flex',alignItems:'center',justifyContent:'center',width:26,height:26,borderRadius:6,background:'var(--surface)',border:'1px solid var(--border)',color:'var(--text3)',cursor:'pointer'}}>{exp?<ChevronUp size={12}/>:<ChevronDown size={12}/>}</button>
          </div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap',marginBottom:10}}>
          <span style={{fontSize:12.5,color:'var(--text2)',fontWeight:500}}>{job.company}</span>
          <span style={{color:'var(--border2)',fontSize:10}}>|</span>
          <span style={{fontSize:11.5,color:'var(--text3)',display:'flex',alignItems:'center',gap:3}}><MapPin size={10}/>{job.location}</span>
          {job.posted&&<><span style={{color:'var(--border2)',fontSize:10}}>|</span><span style={{fontSize:11,color:'var(--text3)',display:'flex',alignItems:'center',gap:3}}><Clock size={10}/>{job.posted}</span></>}
          {job.source&&<Badge>{job.source}</Badge>}
          {job.suggested_action&&<Badge color={ac[job.suggested_action]||'default'} dot>{job.suggested_action}</Badge>}
          {acts.sheet&&<Badge color="green" dot>logged</Badge>}
          {acts.notion&&<Badge color="purple" dot>tracked</Badge>}
          {acts.slack&&<Badge color="cyan" dot>notified</Badge>}
        </div>
        <div style={{display:'flex',gap:4,alignItems:'center',flexWrap:'wrap'}}>
          {!job.score&&<Btn small variant="soft" icon={Sparkles} loading={scoring} onClick={()=>onScore(job)}>Score</Btn>}
          {job.link&&<a href={job.link} target="_blank" rel="noopener" style={{display:'inline-flex',alignItems:'center',gap:6,padding:'5px 10px',borderRadius:'var(--rs)',fontSize:11.5,fontWeight:500,fontFamily:'var(--font)',textDecoration:'none',background:'var(--accent)',color:'#fff'}}><ExternalLink size={11}/>Apply</a>}
          {recEmail ? (
            <button onClick={()=>onEmail({...job, recruiter_email: recEmail})} style={{display:'inline-flex',alignItems:'center',gap:6,padding:'5px 10px',borderRadius:'var(--rs)',fontSize:11.5,fontWeight:500,fontFamily:'var(--font)',background:'#3B82F6',color:'#fff',border:'none',cursor:'pointer'}}><Mail size={11}/>Draft to {recEmail}</button>
          ) : (
            <Btn small variant="ghost" icon={Mail} onClick={()=>onEmail(job)} style={{color:'var(--blue)'}}>Email</Btn>
          )}
          {connectors.sheets&&<Btn small variant="ghost" icon={FileSpreadsheet} onClick={async()=>{await onLogSheet(job);setActs(a=>({...a,sheet:true}))}} style={{color:'var(--green)'}}>Sheet</Btn>}
          {connectors.notion&&<Btn small variant="ghost" icon={Layout} onClick={async()=>{await onNotion(job);setActs(a=>({...a,notion:true}))}} style={{color:'var(--purple)'}}>Notion</Btn>}
          {connectors.slack&&<Btn small variant="ghost" icon={MessageSquare} onClick={async()=>{await onSlack(job);setActs(a=>({...a,slack:true}))}} style={{color:'var(--cyan)'}}>Slack</Btn>}
        </div>
      </div>
    </div>
    {exp&&<div style={{marginTop:12,marginLeft:62}} className="fi">
      {job.score_breakdown&&<Breakdown breakdown={job.score_breakdown} rationale={job.rationale}/>}
      <div style={{fontSize:12,color:'var(--text3)',lineHeight:1.65,marginTop:10,padding:'12px 14px',background:'var(--surface)',borderRadius:'var(--rs)',border:'1px solid var(--border)',maxHeight:160,overflow:'auto'}}>{job.description?job.description.replace(/<[^>]*>/g,' ').substring(0,1500):'No description available'}</div>
    </div>}
  </div>
}

function StatCard({label, value, sub, color, icon:I}){
  return <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:'var(--r)',padding:'14px 16px',flex:1,minWidth:120}}>
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
      <p style={{fontSize:10,color:'var(--text4)',fontWeight:600,letterSpacing:'.06em'}}>{label}</p>
      {I&&<I size={14} style={{color:color||'var(--text4)'}}/>}
    </div>
    <p style={{fontSize:24,fontWeight:700,fontFamily:'var(--mono)',color:color||'var(--text)',letterSpacing:'-.02em',lineHeight:1}}>{value}</p>
    {sub&&<p style={{fontSize:10.5,color:'var(--text4)',marginTop:4}}>{sub}</p>}
  </div>
}

function ConnectorDot({name, active, free}){
  return <div style={{display:'flex',alignItems:'center',gap:7,padding:'5px 10px',background:active?'var(--surface2)':'var(--surface)',borderRadius:6,border:`1px solid ${active?'var(--border2)':'var(--border)'}`,transition:'all .2s'}}>
    <span style={{width:6,height:6,borderRadius:'50%',background:active?'var(--green)':'var(--text4)',boxShadow:active?'0 0 6px var(--green)':'none'}}/>
    <span style={{fontSize:11,fontWeight:500,color:active?'var(--text)':'var(--text4)'}}>{name}</span>
  </div>
}

function NavItem({icon:I, label, active, count, onClick}){
  return <button onClick={onClick} style={{display:'flex',alignItems:'center',gap:9,width:'100%',padding:'7px 10px',borderRadius:'var(--rs)',background:active?'var(--surface2)':'transparent',border:active?'1px solid var(--border)':'1px solid transparent',cursor:'pointer',color:active?'var(--text)':'var(--text3)',fontFamily:'var(--font)',fontSize:12.5,fontWeight:active?600:400,transition:'all .15s'}}>
    <I size={15} style={{opacity:active?1:.5}}/><span style={{flex:1,textAlign:'left'}}>{label}</span>
    {count!=null&&<span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text4)',background:'var(--surface)',padding:'1px 6px',borderRadius:8,border:'1px solid var(--border)'}}>{count}</span>}
  </button>
}

export default function App(){
  const [jobs,setJobs]=useState([])
  const [query,setQuery]=useState('Entrepreneur in Residence AI startup')
  const [location,setLoc]=useState('India')
  const [searching,setSearching]=useState(false)
  const [scoringAll,setScoringAll]=useState(false)
  const [scoringId,setScoringId]=useState(null)
  const [emailJob,setEmailJob]=useState(null)
  const [scoreJob,setScoreJob]=useState(null)
  const [globalResume,setGlobalResume]=useState(null)
  const [showGlobalResume,setShowGlobalResume]=useState(false)
  const [toast,setToast]=useState(null)
  const [view,setView]=useState('search')
  const [sortBy,setSort]=useState('score')
  const [filterAct,setFilter]=useState('all')
  const [selSrc,setSelSrc]=useState(['linkedin','naukri','indeed','iimjobs','foundit'])
  const [connectors,setConnectors]=useState({})
  const [activity,setActivity]=useState([])

  const allSrc=[
    {key:'remotive',label:'Remotive',color:'#5850EC',free:true},
    {key:'arbeitnow',label:'Arbeitnow',color:'#FF6B6B',free:true},
    {key:'adzuna',label:'Adzuna',color:'#36B37E'},
    {key:'jsearch',label:'JSearch',color:'#F97316'},
    {key:'google_jobs',label:'Google Jobs',color:'#4285F4'},
    {key:'linkedin',label:'LinkedIn',color:'#0A66C2'},
    {key:'naukri',label:'Naukri',color:'#4A90D9'},
    {key:'indeed',label:'Indeed',color:'#2164F3'},
    {key:'iimjobs',label:'IIMJobs',color:'#FF6B35'},
    {key:'foundit',label:'Foundit',color:'#6C5CE7'},
  ]

  useEffect(()=>{
    fetch(`${API}/connectors/status`).then(r=>r.json()).then(d=>setConnectors(d.connectors||{})).catch(()=>{})
  },[])

  const toggle=k=>setSelSrc(p=>p.includes(k)?p.filter(s=>s!==k):[...p,k])
  const notify=(m,t='ok')=>{setToast({m,t});setTimeout(()=>setToast(null),3500)}
  const refreshActivity=()=>fetch(`${API}/activity`).then(r=>r.json()).then(d=>setActivity(d.log||[])).catch(()=>{})

  const scored=jobs.filter(j=>j.score!=null)
  const avg=scored.length?Math.round(scored.reduce((s,j)=>s+j.score,0)/scored.length):0
  const hot=scored.filter(j=>j.score>=75).length

  const doSearch=async()=>{
    setSearching(true)
    try{
      const r=await fetch(`${API}/search`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query,location,sources:selSrc})})
      const d=await r.json();if(d.error)throw new Error(d.error)
      setJobs(p=>{const ex=new Set(p.map(j=>j.id));return[...p,...(d.jobs||[]).filter(j=>!ex.has(j.id))]})
      const errCount=Object.keys(d.errors||{}).length
      notify(`Found ${d.count} jobs${errCount?` (${errCount} source errors)`:''}`)
      if(!globalResume) setShowGlobalResume(true)
      refreshActivity()
    }catch(e){notify(e.message,'err')}
    setSearching(false)
  }

  const doScore=async job=>{
    if(!globalResume) return setScoreJob(job)
    setScoringId(job.id)
    try{
      const fd = new FormData()
      fd.append('resume', globalResume)
      fd.append('job', JSON.stringify(job))
      const r=await fetch(`${API}/score`,{method:'POST',body:fd})
      const d=await r.json();if(d.error)throw new Error(d.error)
      setJobs(p=>p.map(j=>j.id===job.id?d.job:j))
      notify('Dynamically graded against your resume!')
      refreshActivity()
    }catch(e){notify(e.message,'err')}
    setScoringId(null)
  }

  const doScoreAll=async()=>{setScoringAll(true);for(const j of jobs.filter(j=>j.score==null))await doScore(j);setScoringAll(false);notify('All jobs scored!');refreshActivity()}
  const doSheet=async j=>{try{await fetch(`${API}/sheets/log`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_id:j.id,job:j})});notify('Logged to Google Sheets');refreshActivity()}catch(e){notify(e.message,'err')}}
  const doNotion=async j=>{try{await fetch(`${API}/notion/create`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_id:j.id,job:j})});notify('Notion card created');refreshActivity()}catch(e){notify(e.message,'err')}}
  const doSlack=async j=>{try{await fetch(`${API}/slack/notify`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_id:j.id,job:j})});notify('Slack notification sent');refreshActivity()}catch(e){notify(e.message,'err')}}
  const doLogAll=async()=>{try{const r=await fetch(`${API}/sheets/log-all`,{method:'POST'});const d=await r.json();notify(`Logged ${d.logged} jobs to Sheets`);refreshActivity()}catch(e){notify(e.message,'err')}}

  let dj=[...jobs];if(filterAct!=='all')dj=dj.filter(j=>j.suggested_action===filterAct)
  dj.sort((a,b)=>sortBy==='score'?(b.score||-1)-(a.score||-1):(a.company||'').localeCompare(b.company||''))
  const vj=view==='hot'?dj.filter(j=>j.score>=75):view==='pipeline'?dj.filter(j=>j.score!=null):dj

  const QS=['Entrepreneur in Residence AI startup','Chief of Staff startup','Product Manager B2B SaaS','Growth Manager startup','Strategy Operations','VC Analyst']

  return <>
    <style>{CSS}</style>

    {toast&&<div style={{position:'fixed',top:16,right:16,zIndex:2000,background:toast.t==='err'?'var(--red-bg)':'var(--green-bg)',color:toast.t==='err'?'var(--red)':'var(--green)',border:`1px solid ${toast.t==='err'?'var(--red-bd)':'var(--green-bd)'}`,borderRadius:8,padding:'10px 16px',fontSize:12,fontWeight:500,display:'flex',alignItems:'center',gap:8,boxShadow:'0 8px 32px rgba(0,0,0,.3)',backdropFilter:'blur(8px)'}} className="fi">
      {toast.t==='err'?<AlertCircle size={13}/>:<CheckCircle size={13}/>}{toast.m}
    </div>}

    {emailJob&&<EmailModal job={emailJob} onClose={()=>setEmailJob(null)}/>}
    {showGlobalResume&&<GlobalResumeModal onClose={()=>setShowGlobalResume(false)} onSet={f=>setGlobalResume(f)}/>}
    {scoreJob&&<ScoreModal job={scoreJob} onClose={()=>setScoreJob(null)} onScored={(j, f)=>{
      if(f) setGlobalResume(f)
      setJobs(p=>p.map(x=>x.id===j.id? j : x))
      setScoreJob(null)
      notify('Dynamically graded against your resume!')
      refreshActivity()
    }}/>}


    <div style={{display:'flex',minHeight:'100vh'}}>
      {/* Sidebar */}
      <aside style={{width:220,background:'var(--bg2)',borderRight:'1px solid var(--border)',padding:'20px 12px',display:'flex',flexDirection:'column',flexShrink:0,position:'sticky',top:0,height:'100vh',overflow:'auto'}}>
        <div style={{marginBottom:24,padding:'0 4px'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:2}}>
            <div style={{width:28,height:28,borderRadius:4,background:'var(--accent)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:800,fontFamily:'var(--mono)',color:'#fff',boxShadow:'0 2px 4px rgba(0,95,75,.2)'}}>R</div>
            <span style={{fontSize:16,fontWeight:700,letterSpacing:'-.03em'}}>Rolynq</span>
          </div>
          <p style={{fontSize:10,color:'var(--text4)',paddingLeft:36,letterSpacing:'.02em'}}>Job search assistant</p>
        </div>

        <nav style={{display:'flex',flexDirection:'column',gap:1}}>
          <NavItem icon={Search} label="Search" active={view==='search'} onClick={()=>setView('search')}/>
          <NavItem icon={BarChart3} label="Pipeline" active={view==='pipeline'} onClick={()=>setView('pipeline')} count={scored.length}/>
          <NavItem icon={Zap} label="Hot Leads" active={view==='hot'} onClick={()=>setView('hot')} count={hot}/>
          <NavItem icon={Activity} label="Activity" active={view==='activity'} onClick={()=>{setView('activity');refreshActivity()}}/>
        </nav>

        <div style={{borderTop:'1px solid var(--border)',margin:'14px 0'}}/>

        <p style={{fontSize:9,color:'var(--text4)',fontWeight:700,letterSpacing:'.08em',padding:'0 10px',marginBottom:6}}>CONNECTORS</p>
        <div style={{display:'flex',flexDirection:'column',gap:3,padding:'0 2px',marginBottom:14}}>
          <ConnectorDot name="Remotive" active={connectors.remotive} free/>
          <ConnectorDot name="Arbeitnow" active={connectors.arbeitnow} free/>
          <ConnectorDot name="Adzuna" active={connectors.adzuna}/>
          <ConnectorDot name="JSearch" active={connectors.jsearch}/>
          <ConnectorDot name="SerpAPI" active={connectors.serpapi}/>
          <ConnectorDot name="Gmail" active={connectors.gmail}/>
          <ConnectorDot name="Sheets" active={connectors.sheets}/>
          <ConnectorDot name="Notion" active={connectors.notion}/>
          <ConnectorDot name="Slack" active={connectors.slack}/>
        </div>

        <div style={{borderTop:'1px solid var(--border)',margin:'0 0 14px'}}/>
        <p style={{fontSize:9,color:'var(--text4)',fontWeight:700,letterSpacing:'.08em',padding:'0 10px',marginBottom:6}}>SOURCES</p>
        <div style={{display:'flex',flexDirection:'column',gap:2,padding:'0 2px'}}>
          {allSrc.map(s=>{
            const on=selSrc.includes(s.key)
            return <button key={s.key} onClick={()=>toggle(s.key)} style={{display:'flex',alignItems:'center',gap:7,padding:'4px 8px',background:on?'var(--surface2)':'transparent',border:on?'1px solid var(--border)':'1px solid transparent',borderRadius:5,cursor:'pointer',fontFamily:'var(--font)',fontSize:11.5,color:on?'var(--text)':'var(--text4)',width:'100%',textAlign:'left',transition:'all .15s'}}>
              <div style={{width:12,height:12,borderRadius:3,border:`1.5px solid ${on?s.color:'var(--border2)'}`,background:on?s.color:'transparent',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,transition:'all .15s'}}>
                {on&&<svg width="7" height="7" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>}
              </div>
              {s.label}
            </button>
          })}
        </div>
      </aside>

      {/* Main */}
      <main style={{flex:1,padding:'24px 32px',minWidth:0}}>

        {jobs.length>0&&<div style={{display:'flex',gap:10,marginBottom:20}} className="fi">
          <StatCard label="TOTAL" value={jobs.length} sub={`${jobs.filter(j=>j.score==null).length} unscored`} icon={Hash}/>
          <StatCard label="SCORED" value={scored.length} color="var(--accent2)" sub={`${Math.round(scored.length/Math.max(jobs.length,1)*100)}% done`} icon={BarChart3}/>
          <StatCard label="AVG SCORE" value={avg||'--'} color={avg>=60?'var(--green)':'var(--orange)'} sub="weighted composite" icon={Target}/>
          <StatCard label="HOT LEADS" value={hot} color="var(--green)" sub="score >= 75" icon={Zap}/>
        </div>}

        <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:'var(--r)',padding:'14px 16px',marginBottom:16}}>
          <div style={{display:'flex',gap:8}}>
            <div style={{flex:1,position:'relative'}}>
              <Search size={14} style={{position:'absolute',left:11,top:'50%',transform:'translateY(-50%)',color:'var(--text4)'}}/>
              <input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doSearch()} placeholder="Search jobs across all sources..." style={{width:'100%',paddingLeft:34}}/>
            </div>
            <input value={location} onChange={e=>setLoc(e.target.value)} placeholder="Location" style={{width:130}}/>
            <Btn onClick={doSearch} loading={searching} icon={Search}>Search</Btn>
          </div>
          {jobs.length===0&&<div style={{display:'flex',gap:6,marginTop:10,flexWrap:'wrap'}}>
            {QS.map(q=><button key={q} onClick={()=>setQuery(q)} style={{background:'var(--surface)',border:'1px solid var(--border)',color:'var(--text3)',borderRadius:16,padding:'4px 12px',fontSize:11,cursor:'pointer',fontFamily:'var(--font)',transition:'all .15s'}}>{q}</button>)}
          </div>}
        </div>

        {jobs.length>0&&<div style={{display:'flex',alignItems:'center',gap:6,marginBottom:14,flexWrap:'wrap'}}>
          <Btn small variant="soft" icon={Sparkles} onClick={doScoreAll} loading={scoringAll}>Score All ({jobs.filter(j=>j.score==null).length})</Btn>
          {connectors.sheets&&<Btn small variant="secondary" icon={FileSpreadsheet} onClick={doLogAll}>Log All to Sheets</Btn>}
          <div style={{marginLeft:'auto',display:'flex',gap:6}}>
            <select value={filterAct} onChange={e=>setFilter(e.target.value)} style={{padding:'4px 8px',fontSize:11}}>
              <option value="all">All actions</option><option value="apply">Apply</option><option value="email">Email</option><option value="save">Save</option><option value="skip">Skip</option>
            </select>
            <select value={sortBy} onChange={e=>setSort(e.target.value)} style={{padding:'4px 8px',fontSize:11}}>
              <option value="score">Score</option><option value="company">Company</option>
            </select>
          </div>
        </div>}

        {view==='search'&&jobs.length===0&&!searching&&<div style={{textAlign:'center',padding:'60px 20px',background:'var(--bg2)',borderRadius:'var(--r)',border:'1px solid var(--border)'}}>
          <div style={{width:52,height:52,borderRadius:14,background:'var(--accent-bg)',border:'1px solid var(--accent-bd)',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 16px'}}><Compass size={24} style={{color:'var(--accent2)'}}/></div>
          <h2 style={{fontSize:17,fontWeight:700,marginBottom:6}}>Start your search</h2>
          <p style={{fontSize:12.5,color:'var(--text3)',marginBottom:0,maxWidth:380,margin:'0 auto 20px'}}>Pull live jobs, score against your profile, and take real actions.</p>
        </div>}

        {view==='activity'&&<div className="fi">
          <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:'var(--r)',padding:16}}>
            <h3 style={{fontSize:13,fontWeight:600,marginBottom:12,display:'flex',alignItems:'center',gap:6}}><Activity size={14} style={{color:'var(--accent2)'}}/>Activity Log</h3>
            {activity.length===0?<p style={{fontSize:12,color:'var(--text4)',textAlign:'center',padding:32}}>No activity yet. Search and score some jobs!</p>
            :<div style={{display:'flex',flexDirection:'column',gap:4}}>
              {activity.map((a,i)=><div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',background:'var(--surface)',borderRadius:6,border:'1px solid var(--border)'}} className="si">
                <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text4)',flexShrink:0}}>{a.time}</span>
                <Badge color={a.action==='search'?'accent':a.action==='scored'?'orange':a.action==='emailed'?'blue':a.action==='sheet_logged'?'green':a.action==='notion_created'?'purple':'default'}>{a.action}</Badge>
                <span style={{fontSize:12,color:'var(--text2)',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.job_title}{a.company?` @ ${a.company}`:''}</span>
                {a.detail&&<span style={{fontSize:10.5,color:'var(--text4)',flexShrink:0}}>{a.detail}</span>}
              </div>)}
            </div>}
          </div>
        </div>}

        {view!=='activity'&&<div style={{display:'flex',flexDirection:'column',gap:6}}>
          {vj.map((j,i)=><JobCard key={j.id||i} job={j} onScore={doScore} scoring={scoringId===j.id} onEmail={setEmailJob} onLogSheet={doSheet} onNotion={doNotion} onSlack={doSlack} connectors={connectors}/>)}
        </div>}

        {view==='hot'&&jobs.length>0&&vj.length===0&&<div style={{textAlign:'center',padding:48,color:'var(--text4)'}}><Zap size={24} style={{marginBottom:8,opacity:.4}}/><p style={{fontSize:12}}>No hot leads yet. Score jobs to find top matches.</p></div>}
        {view==='pipeline'&&jobs.length>0&&vj.length===0&&<div style={{textAlign:'center',padding:48,color:'var(--text4)'}}><BarChart3 size={24} style={{marginBottom:8,opacity:.4}}/><p style={{fontSize:12}}>Pipeline empty. Score some jobs to populate.</p></div>}
      </main>
    </div>
  </>
}
